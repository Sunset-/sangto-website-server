module.exports = {
    SUCCESS: 200,
    DEFAULT_ERROR_CODE: 500,
    UNAUTHORIZED: 401,
    UNLOGINED: 40000
}