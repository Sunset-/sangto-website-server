module.exports = {
    //target: 'http://192.168.0.148:40000/manage-service',
    // target: 'http://192.168.0.148:40001/manage-service',
    // target: 'http://127.0.0.1:9000/manager',
    target: 'http://192.168.0.148:8085/manager',
    prefix : '/proxy'
};