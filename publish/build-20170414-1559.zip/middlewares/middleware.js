const mws = ['./static','./redisSession','./logger','./responseWrapper','./LoginedChecker','./wechatXml','./requestBody','./proxy'];
//'./redisSession','
//'./memorySession',
//'./authorityIntercept.js',

module.exports = (app) => {
    mws.forEach(mv => {
        require(mv)(app);
    })
}