module.exports = {
    ORDERS_STATUS: {
        UN_PAY: '0',//未支付
        PAYED: '1',//微信支付成功
        NOTIFYED: '2',//已通知停车场系统
        PAST_DUE: '3'//过期
    }
};