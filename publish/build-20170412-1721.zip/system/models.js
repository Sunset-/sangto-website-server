module.exports = [
    'ManagerAccountRouter',
    'ManagerSignRouter',
    'DictionaryTypeRouter',
    'DictionaryItemRouter',
    'SystemVariableRouter',
    'FileUploadRouter'
]