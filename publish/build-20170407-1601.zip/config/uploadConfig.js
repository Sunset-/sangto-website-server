const path = require('path');

module.exports = {
    uploadDir : path.resolve(__dirname,'../upload')
}